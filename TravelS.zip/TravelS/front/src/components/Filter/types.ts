type CityType = {
    id: number;
    title: string;
};

type RestItemType = {
    id: number;
    title: string;
    color: string;
};

