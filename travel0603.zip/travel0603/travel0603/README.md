## База данных

База данных создана в PostgreSQL с помощью графического редактора PgAdmin 4. 
Прикреплена к репозиторию

## Инициализация docker-compose

```
docker-compose up -d --force-recreate

После запуска перейти на localhost:8180
