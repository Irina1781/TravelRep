const { Sequelize } = require('sequelize');

const sequelize = new Sequelize("postgres", "postgres", "nitocris", {
    host: 'postgres_db',
    dialect: 'postgres', 
    port: 5432,
  });

module.exports = sequelize;