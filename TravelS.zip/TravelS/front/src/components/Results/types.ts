export interface ResultItemInterface {
    city: string;
    type: string;
    description: string;
}