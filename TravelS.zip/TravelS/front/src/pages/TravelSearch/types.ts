export interface ClimateListProps {
    id: number;
    climate: string;
  }

  export interface TimezoneListProps {
    id: number;
    timezone: string;
  }

  export interface CityListProps {
    id: number;
    city: string;
  }
